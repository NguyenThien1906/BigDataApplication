redis-cli flushall
clear
