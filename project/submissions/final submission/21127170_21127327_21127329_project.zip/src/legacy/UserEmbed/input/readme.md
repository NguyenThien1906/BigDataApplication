These files are retrieved from user profiles and ratings on item titles.

For testing purposes, these files are made from scratch, not collected from an API, and soon to be joined with user dataset (data/user-details-2023.csv) to gather info.
