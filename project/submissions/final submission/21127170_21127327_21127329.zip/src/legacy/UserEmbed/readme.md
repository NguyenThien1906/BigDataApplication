Repository for embedding user input to a unified format.

Input: see user_input.json for more details.
Output: /output_embed
