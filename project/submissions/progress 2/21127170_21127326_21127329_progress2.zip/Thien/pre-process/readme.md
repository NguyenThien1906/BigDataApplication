Repository for dataset pre-process:

- datasets\_prep.ipynb: a thoroughly detailed source code and explanation on how we deal with the data.

- /results: pre-processed dataset, partially. (read /results/readme.pdf for more details)
