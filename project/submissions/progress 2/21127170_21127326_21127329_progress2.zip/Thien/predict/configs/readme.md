These files are retrieved from performing data preprocessing.
