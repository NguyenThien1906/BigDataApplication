Repository for user prediction: only embedding done.

- user\_embed.ipynb: main source code with explanation.

- user\_embed.py: a short version of user\_embed.ipynb to cut some time.

- user\_input.json: input configuration.

- /configs: extra configuration files.

- /input: user inputs.

- /output: results of the embeddin process.
